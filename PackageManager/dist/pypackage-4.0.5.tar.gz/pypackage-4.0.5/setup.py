from setuptools import setup
setup(
    name="pypackage",
    version="4.0.5",
    long_description="In this Python version lots of changes you'll have to see.",
    author="Coder",
    packages=['pypackage'],
    install_requires= []
)
